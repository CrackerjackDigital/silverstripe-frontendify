/* global global */
// Setup for running Mocha via Node
require( "should/should" );

global._ = require( "lodash" );

global.postal = require( "../../lib/postal.lodash.js" );
