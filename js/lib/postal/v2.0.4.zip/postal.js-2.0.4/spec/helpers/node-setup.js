// Setup for running Mocha via Node
require( "should/should" );

global.postal = require( "../../lib/postal.js" );
