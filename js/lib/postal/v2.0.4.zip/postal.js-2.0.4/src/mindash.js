var _ = {
	after: require( "lodash/after" ),
	some: require( "lodash/some" ),
	bind: require( "lodash/bind" ),
	debounce: require( "lodash/debounce" ),
	each: require( "lodash/each" ),
	extend: require( "lodash/assign" ),
	filter: require( "lodash/filter" ),
	isEqual: require( "lodash/isEqual" ),
	keys: require( "lodash/keys" ),
	map: require( "lodash/map" ),
	throttle: require( "lodash/throttle" )
};
